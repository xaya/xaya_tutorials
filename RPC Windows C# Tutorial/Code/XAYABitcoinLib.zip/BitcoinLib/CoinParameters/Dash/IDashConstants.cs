﻿namespace BitcoinLib.CoinParameters.Dash
{
    public interface IDashConstants
    {
        DashConstants.Constants Constants { get; }
    }
}