﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BitcoinLib.Responses
{
    public class GetAddressesByLabelResponse
    {
        public string Purpose;
    }
}
