﻿// Copyright (c) 2014 - 2016 George Kimionis
// See the accompanying file LICENSE for the Software License Aggrement

namespace BitcoinLib.CoinParameters.Litecoin
{
    public interface ILitecoinConstants
    {
        LitecoinConstants.Constants Constants { get; }
    }
}