﻿namespace BitcoinLib.CoinParameters.Smartcash
{
  public interface ISmartcashConstants
  {
    SmartcashConstants.Constants Constants { get; }
  }
}