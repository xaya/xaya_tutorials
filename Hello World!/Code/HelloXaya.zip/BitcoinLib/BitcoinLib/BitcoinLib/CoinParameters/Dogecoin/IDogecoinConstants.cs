﻿// Copyright (c) 2014 - 2016 George Kimionis
// See the accompanying file LICENSE for the Software License Aggrement

namespace BitcoinLib.CoinParameters.Dogecoin
{
    public interface IDogecoinConstants
    {
        DogecoinConstants.Constants Constants { get; }
    }
}